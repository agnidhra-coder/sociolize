abstract class PostsEvent {}

class FetchPosts extends PostsEvent {}