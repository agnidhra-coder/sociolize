import 'package:api_fetch/features/fetch_api/domain/enitities/post_entity.dart';

abstract class PostsState {}

class PostsInitial extends PostsState{}

class PostsLoading extends PostsState{}

class PostsLoaded extends PostsState{
  final List<PostEntity> posts;

  PostsLoaded({required this.posts});
}

class PostsError extends PostsState{
  final String message;

  PostsError({required this.message});

}