import 'package:api_fetch/features/fetch_api/domain/usecases/fetch_posts_use_case.dart';
import 'package:api_fetch/features/fetch_api/presentation/bloc/posts_event.dart';
import 'package:api_fetch/features/fetch_api/presentation/bloc/posts_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class PostsBloc extends Bloc<PostsEvent, PostsState>{
  final FetchPostsUseCase fetchPostsUseCase;

  PostsBloc({required this.fetchPostsUseCase}) : super (PostsInitial()){
    on<FetchPosts> (_onFetchPosts);
  }

  Future<void> _onFetchPosts(FetchPosts event, Emitter<PostsState> emit) async {
    emit(PostsLoading());
    try{
      final posts = await fetchPostsUseCase();
      emit(PostsLoaded(posts: posts));
    } catch(e){
      emit(PostsError(message: 'Failed to load posts'));
      print(e);
    }
  }

}