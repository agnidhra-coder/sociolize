import 'package:flutter/widgets.dart';
import 'package:google_fonts/google_fonts.dart';

class PostTile extends StatelessWidget {
  final String title;
  final String body;
  const PostTile({super.key, required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Text(
            title,
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.w200
            )
          ),
          SizedBox(height: 6,),
          Text(
            body,
            style: GoogleFonts.poppins(),
          )
        ],
      ),
      
    );
  }
}