import 'package:api_fetch/features/fetch_api/presentation/bloc/posts_bloc.dart';
import 'package:api_fetch/features/fetch_api/presentation/bloc/posts_state.dart';
import 'package:api_fetch/features/fetch_api/presentation/widgets/post_tile.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';

class PostsPage extends StatefulWidget {
  const PostsPage({super.key});

  @override
  State<PostsPage> createState() => _PostsPageState();
}

class _PostsPageState extends State<PostsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 39, 39, 39),
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(30),
        child: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 16.0),
            child: Text(
              'Recent Posts',
              style: GoogleFonts.poppins(
                color: const Color.fromARGB(255, 199, 199, 199),
                fontSize: 25.0,
              ),
            ),
          ),
          SizedBox(height: 20,),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: const Color.fromARGB(255, 58, 58, 58),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                )
              ),
              child: BlocBuilder<PostsBloc, PostsState>(
                builder: (context, state){
                  if(state is PostsLoading){
                    return Center(
                      child: SpinKitThreeBounce(
                        color: Colors.white70,
                        size: 25,
                      ),
                    );
                  } else if(state is PostsLoaded){
                      return ListView.builder(
                        itemCount: state.posts.length,
                        itemBuilder: (context, index) {
                          final post = state.posts[index];
                          return PostTile(title: post.title, body: post.body);
                        }
                      );
                  } else if (state is PostsError){
                    return Center(child: Text(state.message),);
                  }

                  return Center(
                    child: Text(
                      'No Posts Found',
                      style: GoogleFonts.poppins(
                        color: Colors.grey
                      ),
                    ),
                  );
                }
                
              ),
            ),
          )
        ],
      ),
    );
  }
}