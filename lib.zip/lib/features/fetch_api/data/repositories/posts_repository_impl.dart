import 'package:api_fetch/features/fetch_api/data/datasources/posts_remote_data_source.dart';
import 'package:api_fetch/features/fetch_api/domain/enitities/post_entity.dart';
import 'package:api_fetch/features/fetch_api/domain/repositories/posts_repository.dart';

class PostsRepositoryImpl implements PostsRepository{
  final PostsRemoteDataSource postsRemoteDataSource;

  PostsRepositoryImpl({required this.postsRemoteDataSource});

  @override
  Future<List<PostEntity>> fetchPosts() async{
    return await postsRemoteDataSource.fetchPosts();
  }
}